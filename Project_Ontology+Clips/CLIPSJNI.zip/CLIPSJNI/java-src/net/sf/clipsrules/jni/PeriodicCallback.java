package net.sf.clipsrules.jni;

public interface PeriodicCallback 
  {
   public void periodicCallback();
  }
